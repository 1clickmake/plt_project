<?php

namespace App\Controllers;

use App\Core\Database;

class VendorController extends BaseController {
    public function index() {
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            $this->redirect('/login');
            return;
        }
        $this->view('vendor/index');
    }
    public function settings() {
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            $this->redirect('/login');
        }

        $userId = $_SESSION['user']['user_id'];
        $db = Database::getInstance();

        // Fetch existing settings
        $stmt = $db->prepare("SELECT * FROM vendor_settings WHERE user_id = :uid");
        $stmt->execute(['uid' => $userId]);
        $settings = $stmt->fetch();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $companyName = $_POST['company_name'] ?? '';
            $urlSlug = $_POST['url_slug'] ?? '';
            $contactNumber = $_POST['contact_number'] ?? '';
            $headquartersAddress = $_POST['headquarters_address'] ?? '';
            $faxNumber = $_POST['fax_number'] ?? '';
            $managerName = $_POST['manager_name'] ?? '';
            $bankAccount = $_POST['bank_account'] ?? '';
            $managerEmail = $_POST['manager_email'] ?? '';
            $factoryAddress = $_POST['factory_address'] ?? '';
            $factoryContact = $_POST['factory_contact'] ?? '';

            // Logo upload handling (basic)
            $companyLogo = $settings['company_logo'] ?? '';
            if (isset($_FILES['company_logo']) && $_FILES['company_logo']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../../public/data/logo/';
                if (!file_exists($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $filename = 'logo_' . $userId . '_' . time() . '.' . pathinfo($_FILES['company_logo']['name'], PATHINFO_EXTENSION);
                if (move_uploaded_file($_FILES['company_logo']['tmp_name'], $uploadDir . $filename)) {
                    $companyLogo = '/data/logo/' . $filename;
                }
            }

            // Excel upload and parsing
            $priceExcelPath = $settings['price_excel_path'] ?? null;
            $pricesData = $settings['prices_data'] ?? null;

            if (isset($_FILES['price_excel']) && $_FILES['price_excel']['error'] === UPLOAD_ERR_OK) {
                $uploadDirExcel = __DIR__ . '/../../public/data/excel/';
                if (!file_exists($uploadDirExcel)) {
                    @mkdir($uploadDirExcel, 0777, true);
                }
                $excelFilename = 'price_' . $userId . '_' . time() . '.' . pathinfo($_FILES['price_excel']['name'], PATHINFO_EXTENSION);
                $fullExcelPath = $uploadDirExcel . $excelFilename;
                
                if (@move_uploaded_file($_FILES['price_excel']['tmp_name'], $fullExcelPath)) {
                    $priceExcelPath = '/data/excel/' . $excelFilename;
                    
                    try {
                        // AI 파싱이 오래 걸릴 수 있으므로 PHP 실행 시간 무제한(또는 300초)으로 연장
                        set_time_limit(300);
                        
                        // AI-driven Excel Parsing
                        $aiService = \App\Services\AI\AIExtractorFactory::create();
                        $excelText = $aiService->extractTextFromExcel($fullExcelPath);
                        $extractedPricing = $aiService->extractPricingFromJson($excelText);
                        
                        // 검증 로직 추가 (AI가 일부 값을 찾지 못했거나 실패한 경우 방어)
                        if (isset($extractedPricing['validation']['is_complete']) && $extractedPricing['validation']['is_complete'] !== true) {
                            $missing = implode(", ", $extractedPricing['validation']['missing_fields'] ?? ['Unknown']);
                            throw new \Exception("AI 파싱이 불완전합니다. 누락된 필드: " . $missing);
                        }

                        // 원본 파일명 삽입
                        if (!isset($extractedPricing['meta'])) {
                            $extractedPricing['meta'] = [];
                        }
                        $extractedPricing['meta']['source_file'] = $_FILES['price_excel']['name'];

                        $pricesData = json_encode($extractedPricing, JSON_UNESCAPED_UNICODE);

                        // Save to vendor_pricing_rules (Versioning)
                        $insertRuleStmt = $db->prepare("INSERT INTO vendor_pricing_rules (vendor_id, applied_month, source_file, pricing_data) VALUES (:vid, :am, :sf, :pd)");
                        $insertRuleStmt->execute([
                            'vid' => $userId,
                            'am' => $extractedPricing['meta']['base_month'] ?? date('Y-m'),
                            'sf' => $_FILES['price_excel']['name'],
                            'pd' => $pricesData
                        ]);

                        // Redirect to settings page with success message
                        // For now just continue...
                    } catch (\Exception $e) {
                        // Keep old data if parsing fails
                        error_log("Gemini AI Parsing Failed: " . $e->getMessage());
                    }
                } else {
                    echo "<script>alert('파일 업로드 실패 (권한 문제). 서버의 public/data/excel 폴더 쓰기 권한을 확인해 주세요!'); window.history.back();</script>";
                    return;
                }
            }

            try {
                if ($settings) {
                    $updateStmt = $db->prepare("UPDATE vendor_settings SET company_name = :cn, url_slug = :us, contact_number = :cnm, company_logo = :logo, price_excel_path = :pep, prices_data = :pd, headquarters_address = :hq, fax_number = :fax, manager_name = :mgr, manager_email = :email, factory_address = :faddr, factory_contact = :fcont, bank_account = :bank WHERE user_id = :uid");
                    $updateStmt->execute([
                        'cn' => $companyName,
                        'us' => $urlSlug,
                        'cnm' => $contactNumber,
                        'logo' => $companyLogo,
                        'pep' => $priceExcelPath,
                        'pd' => $pricesData,
                        'hq' => $headquartersAddress,
                        'fax' => $faxNumber,
                        'mgr' => $managerName,
                        'email' => $managerEmail,
                        'bank' => $bankAccount,
                        'faddr' => $factoryAddress,
                        'fcont' => $factoryContact,
                        'uid' => $userId
                    ]);
                } else {
                    $insertStmt = $db->prepare("INSERT INTO vendor_settings (user_id, company_name, url_slug, contact_number, company_logo, price_excel_path, prices_data, headquarters_address, fax_number, manager_name, manager_email, factory_address, factory_contact, bank_account) VALUES (:uid, :cn, :us, :cnm, :logo, :pep, :pd, :hq, :fax, :mgr, :email, :faddr, :fcont, :bank)");
                    $insertStmt->execute([
                        'uid' => $userId,
                        'cn' => $companyName,
                        'us' => $urlSlug,
                        'cnm' => $contactNumber,
                        'logo' => $companyLogo,
                        'pep' => $priceExcelPath,
                        'pd' => $pricesData,
                        'hq' => $headquartersAddress,
                        'fax' => $faxNumber,
                        'mgr' => $managerName,
                        'email' => $managerEmail,
                        'bank' => $bankAccount,
                        'faddr' => $factoryAddress,
                        'fcont' => $factoryContact
                    ]);
                }
                echo "<script>alert('Settings updated successfully!'); window.location.href='/vendor/settings';</script>";
                return;
            } catch (\PDOException $e) {
                // If url_slug is duplicate
                echo "<script>alert('Error updating settings. (URL slug might be duplicate)'); window.location.href='/vendor/settings';</script>";
                return;
            }
        }

        $this->view('vendor/settings', ['settings' => $settings]);
    }

    public function pricing() {
        $this->requireVendorEmployees();
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            $this->redirect('/login');
            return;
        }
        if (!isset($_SESSION['employee_id'])) {
            $this->redirect('/vendor/profiles');
            return;
        }

        $userId = $_SESSION['user']['user_id'];
        $db = Database::getInstance();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_FILES['price_excel']) && $_FILES['price_excel']['error'] === UPLOAD_ERR_OK) {
                $uploadDirExcel = __DIR__ . '/../../public/data/excel/';
                if (!file_exists($uploadDirExcel)) {
                    @mkdir($uploadDirExcel, 0777, true);
                }
                $excelFilename = 'price_' . $userId . '_' . time() . '.' . pathinfo($_FILES['price_excel']['name'], PATHINFO_EXTENSION);
                $fullExcelPath = $uploadDirExcel . $excelFilename;
                
                if (@move_uploaded_file($_FILES['price_excel']['tmp_name'], $fullExcelPath)) {
                    $priceExcelPath = '/data/excel/' . $excelFilename;
                    
                    try {
                        // AI 파싱이 오래 걸릴 수 있으므로 PHP 실행 시간 무제한(또는 300초)으로 연장
                        set_time_limit(300);
                        
                        // AI-driven Excel Parsing
                        $aiService = \App\Services\AI\AIExtractorFactory::create();
                        $excelText = $aiService->extractTextFromExcel($fullExcelPath);
                        $extractedPricing = $aiService->extractPricingFromJson($excelText);
                        
                        if (isset($extractedPricing['validation']['is_complete']) && $extractedPricing['validation']['is_complete'] !== true) {
                            $missing = implode(", ", $extractedPricing['validation']['missing_fields'] ?? ['Unknown']);
                            throw new \Exception("AI 파싱이 불완전합니다. 누락된 필드: " . $missing);
                        }

                        // 원본 파일명 삽입
                        if (!isset($extractedPricing['meta'])) {
                            $extractedPricing['meta'] = [];
                        }
                        $extractedPricing['meta']['source_file'] = $_FILES['price_excel']['name'];

                        $pricesData = json_encode($extractedPricing, JSON_UNESCAPED_UNICODE);

                        // Save to vendor_pricing_rules
                        $insertRuleStmt = $db->prepare("INSERT INTO vendor_pricing_rules (vendor_id, applied_month, source_file, pricing_data) VALUES (:vid, :am, :sf, :pd)");
                        $insertRuleStmt->execute([
                            'vid' => $userId,
                            'am' => $extractedPricing['meta']['base_month'] ?? date('Y-m'),
                            'sf' => $_FILES['price_excel']['name'],
                            'pd' => $pricesData
                        ]);
                        
                        // Update vendor_settings
                        $stmtCheck = $db->prepare("SELECT id FROM vendor_settings WHERE user_id = :uid");
                        $stmtCheck->execute(['uid' => $userId]);
                        if ($stmtCheck->fetchColumn()) {
                            $updStmt = $db->prepare("UPDATE vendor_settings SET price_excel_path = :pep, prices_data = :pd WHERE user_id = :uid");
                            $updStmt->execute(['pep' => $priceExcelPath, 'pd' => $pricesData, 'uid' => $userId]);
                        } else {
                            $insStmt = $db->prepare("INSERT INTO vendor_settings (user_id, price_excel_path, prices_data) VALUES (:uid, :pep, :pd)");
                            $insStmt->execute(['uid' => $userId, 'pep' => $priceExcelPath, 'pd' => $pricesData]);
                        }

                        echo "<script>alert('단가표가 성공적으로 분석 및 적용되었습니다.'); window.location.href='/vendor/pricing';</script>";
                        return;
                    } catch (\Exception $e) {
                        $errorMsg = addslashes("AI 분석 실패: " . $e->getMessage());
                        echo "<script>alert('{$errorMsg}'); window.history.back();</script>";
                        return;
                    }
                } else {
                    echo "<script>alert('파일 업로드 실패 (권한 문제). 서버의 public/data/excel 폴더 쓰기 권한을 확인해 주세요!'); window.history.back();</script>";
                    return;
                }
            }
        }
        
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $stmtTotal = $db->prepare("SELECT COUNT(*) FROM vendor_pricing_rules WHERE vendor_id = :vuid");
        $stmtTotal->execute(['vuid' => $userId]);
        $totalCount = $stmtTotal->fetchColumn();
        $totalPages = ceil($totalCount / $limit);

        $stmt = $db->prepare("SELECT * FROM vendor_pricing_rules WHERE vendor_id = :vuid ORDER BY id DESC LIMIT :limit OFFSET :offset");
        $stmt->bindValue(':vuid', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        $rules = $stmt->fetchAll();

        // Also fetch current settings for displaying latest uploaded file
        $stmtSettings = $db->prepare("SELECT price_excel_path FROM vendor_settings WHERE user_id = :uid");
        $stmtSettings->execute(['uid' => $userId]);
        $settings = $stmtSettings->fetch();

        $this->view('vendor/pricing', [
            'rules' => $rules,
            'page' => $page,
            'totalPages' => $totalPages,
            'settings' => $settings
        ]);
    }

    public function quotes() {
        $this->requireVendorEmployees();
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            $this->redirect('/login');
            return;
        }
        if (!isset($_SESSION['employee_id'])) {
            $this->redirect('/vendor/profiles');
            return;
        }

        $userId = $_SESSION['user']['user_id'];
        $db = Database::getInstance();

        $stmt = $db->prepare("
            SELECT q.*, e.name as employee_name, e.color_code as employee_color 
            FROM quote_requests q 
            LEFT JOIN vendor_employees e ON q.processed_by = e.id 
            WHERE q.vendor_user_id = :vuid 
            ORDER BY q.created_at DESC
        ");
        $stmt->execute(['vuid' => $userId]);
        $quotes = $stmt->fetchAll();

        // Split quotes into completed and pending
        $completed_quotes = array_filter($quotes, function($q) { return !empty($q['processed_by']); });
        $pending_quotes = array_filter($quotes, function($q) { return empty($q['processed_by']); });

        $this->view('vendor/quotes', [
            'quotes' => $quotes,
            'completed_quotes' => $completed_quotes,
            'pending_quotes' => $pending_quotes,
            'page' => 1,
            'totalPages' => 1
        ]);
    }

    public function quoteDetail($vars) {
        $this->requireVendorEmployees();
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            $this->redirect('/login');
            return;
        }
        if (!isset($_SESSION['employee_id'])) {
            $this->redirect('/vendor/profiles');
            return;
        }

        $userId = $_SESSION['user']['user_id'];
        $quoteId = intval($vars['id'] ?? 0);
        $db = Database::getInstance();

        $stmt = $db->prepare("
            SELECT q.*, e.name as employee_name, e.color_code as employee_color, e.phone as employee_phone, e.title as employee_title
            FROM quote_requests q 
            LEFT JOIN vendor_employees e ON q.processed_by = e.id 
            WHERE q.id = :qid AND q.vendor_user_id = :vuid
        ");
        $stmt->execute(['qid' => $quoteId, 'vuid' => $userId]);
        $quote = $stmt->fetch();

        if (!$quote) {
            echo "<script>alert('존재하지 않거나 접근 권한이 없는 견적 요청입니다.'); window.location.href='/vendor/quotes';</script>";
            return;
        }

        $this->view('vendor/quote_detail', ['quote' => $quote]);
    }

    public function quotePrice($vars) {
        $this->requireVendorEmployees();
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            $this->redirect('/login');
            return;
        }
        if (!isset($_SESSION['employee_id'])) {
            $this->redirect('/vendor/profiles');
            return;
        }

        $userId = $_SESSION['user']['user_id'];
        $quoteId = intval($vars['id'] ?? 0);
        $db = Database::getInstance();

        $stmt = $db->prepare("
            SELECT q.*, e.name as employee_name, e.color_code as employee_color, e.phone as employee_phone, e.title as employee_title
            FROM quote_requests q 
            LEFT JOIN vendor_employees e ON q.processed_by = e.id 
            WHERE q.id = :qid AND q.vendor_user_id = :vuid
        ");
        $stmt->execute(['qid' => $quoteId, 'vuid' => $userId]);
        $quote = $stmt->fetch();

        if (!$quote) {
            echo "<script>alert('존재하지 않거나 접근 권한이 없는 견적 요청입니다.'); window.location.href='/vendor/quotes';</script>";
            return;
        }

        $stmt = $db->prepare("SELECT * FROM vendor_settings WHERE user_id = :uid");
        $stmt->execute(['uid' => $userId]);
        $settings = $stmt->fetch() ?: [];

        $result = $this->buildQuoteModules($quote);
        $modules = $result['modules'];
        $overallTotal = $result['overallTotal'];

                $this->view('vendor/quote_price', [
            'quote' => $quote, 
            'settings' => $settings, 
            'modules' => $modules,
            'overallTotal' => $overallTotal
        ]);
    }

        private function buildQuoteModules($quote) {
        // BOM 계산 로직 (동적 산출)
        require_once __DIR__ . '/../Services/SehwaPriceCalculator.php';
        
        // 견적 당시의 단가표(Rule)를 주입하여 과거 단가 고정
        $vendorId = $quote['vendor_user_id'] ?? 1;
        $ruleId = $quote['pricing_rule_id'] ?? null;
        \App\Services\SehwaPriceCalculator::setRuleContext($vendorId, $ruleId);

        $indep = intval($quote['rack_indep']);
        $conn = intval($quote['rack_conn']);
        $small = intval($quote['rack_small_conn']);
        
        // 단수 (levels) 계산: 엑셀에서 단수는 '로드빔 단수' (예: 2S 3단이면 로드빔 단수는 2단)
        // DB의 rack_levels가 3이면 실제 로드빔은 2단이 됨.
        $levels = intval($quote['rack_levels']) ?: 2;
        $beamLevels = max(1, $levels - 1); 
        
        // 빔 두께와 바(Bar) 타입 
        $barType = intval($quote['beam_thickness'] ?? 125); 
        $beamThick = 1.6; // 일반 파렛트랙 기본 1.6t
        
        $w = intval($quote['pallet_w']);
        $d = intval($quote['pallet_d']);
        if($w == 0) $w = 1100;
        if($d == 0) $d = 1100;

        $rackH = intval(preg_replace('/[^0-9]/', '', $quote['rack_height'] ?? ''));
        if ($rackH <= 0) $rackH = ($quote['pallet_h'] + 150) * $levels;
        
        $entryW = (strpos($quote['fork_direction'], 'W') !== false) ? $w : $d;
        $nonEntryW = (strpos($quote['fork_direction'], 'W') !== false) ? $d : $w;
        $beamL = ($entryW * 2) + 385;
        $depth = $nonEntryW - 100;

        // 모듈별 단위 BOM 계산 클로저
        $buildUnitBom = function($frames, $beamLevels, $tiePerLevel, $rackH, $depth, $beamL, $barType, $beamThick) {
            $bom = [];
            $totalWeight = 0;
            $columns = $frames * 2;
            $beams = $beamLevels * 2;
            $tieBeams = ($beams > 0) ? ($beams / 2) * $tiePerLevel : 0;

            if ($columns > 0) {
                $col = \App\Services\SehwaPriceCalculator::calcColumn(['type' => '85바', 'height' => $rackH, 'thickness' => 1.8, 'qty' => $columns]);
                $bom[] = $col;
                $totalWeight += $col['weight'] * $columns;

                $base = \App\Services\SehwaPriceCalculator::calcColumnBase(['w' => 173, 'd' => 101, 'thickness' => 4, 'qty' => $columns]);
                $bom[] = $base;
                $totalWeight += $base['weight'] * $columns;

                $tie = \App\Services\SehwaPriceCalculator::calcTieBeam(['size' => '75*30', 'length' => $depth + 42, 'thickness' => 1.5, 'material' => '아연도', 'depth' => $depth, 'qty' => $tieBeams]);
                $bom[] = $tie;
                $totalWeight += $tie['weight'] * $tieBeams;

                $x6 = floor(($rackH - 400) / 750);
                $straightCount = $frames * 2;
                $diagonalCount = $frames * $x6;

                $strB = \App\Services\SehwaPriceCalculator::calcBracing(['type' => '직선', 'length' => $depth - 75, 'thickness' => 1.5, 'qty' => $straightCount]);
                $bom[] = $strB;
                $totalWeight += $strB['weight'] * $straightCount;

                $diaLength = sqrt(pow($depth - 125, 2) + pow(750, 2)) + 50;
                $diaB = \App\Services\SehwaPriceCalculator::calcBracing(['type' => '경사', 'length' => $diaLength, 'thickness' => 1.5, 'qty' => $diagonalCount]);
                $bom[] = $diaB;
                $totalWeight += $diaB['weight'] * $diagonalCount;

                $bom[] = \App\Services\SehwaPriceCalculator::getFixedPart('FIX-001', $columns);
                $bom[] = \App\Services\SehwaPriceCalculator::getFixedPart('FIX-002', $columns * 2);
                $bom[] = \App\Services\SehwaPriceCalculator::getFixedPart('FIX-004', $columns * 2);
                
                $bolt65Qty = floor(($columns / 2) * ($x6 + 3));
                $bom[] = \App\Services\SehwaPriceCalculator::getFixedPart('FIX-005', $bolt65Qty);
                $bom[] = \App\Services\SehwaPriceCalculator::getFixedPart('FIX-006', $columns);
            }

            if ($beams > 0) {
                $beam = \App\Services\SehwaPriceCalculator::calcLoadBeam(['length' => $beamL, 'bar_type' => $barType, 'thickness' => $beamThick, 'qty' => $beams]);
                $bom[] = $beam;
                $totalWeight += $beam['weight'] * $beams;

                $bkt = \App\Services\SehwaPriceCalculator::calcLoadBeamBracket(['w' => 101, 'd' => 200, 'thickness' => 4.0, 'qty' => $beams * 2]);
                $bom[] = $bkt;
                $totalWeight += $bkt['weight'] * ($beams * 2);

                $bom[] = \App\Services\SehwaPriceCalculator::getFixedPart('FIX-003', $beams * 2);
            }

            $lossTotal = \App\Services\SehwaPriceCalculator::calcLoss($totalWeight);
            if ($lossTotal > 0) {
                $bom[] = ['name' => 'Loss', 'spec' => '철강 Loss 3%', 'qty' => '-', 'unit_amount' => '-', 'total' => $lossTotal];
            }

            $sumRaw = 0;
            foreach ($bom as $item) {
                $sumRaw += $item['total'];
            }
            $finalPrice = \App\Services\SehwaPriceCalculator::finalAmount($sumRaw);

            return [
                'bom' => $bom,
                'weight' => $totalWeight,
                'raw_price' => $sumRaw,
                'final_price' => $finalPrice
            ];
        };

        $tiePerLevel = intval($quote['rack_tie_per_level'] ?? 4);
        $modules = [];
        $overallTotal = 0;

        if ($indep > 0) {
            $unit = $buildUnitBom(2, $beamLevels, $tiePerLevel, $rackH, $depth, $beamL, $barType, $beamThick);
            $sName = ($beamL >= 2585 ? "2S" : "1S") . " {$levels}단 독립";
            $modules[] = [
                'type' => '독립',
                'name' => '파렛트랙',
                'spec' => "{$beamL}*{$depth}*{$rackH}",
                'remark' => $sName,
                'qty' => $indep,
                'unit_price' => $unit['final_price'],
                'raw_price' => $unit['raw_price'],
                'total_price' => $unit['final_price'] * $indep,
                'bom' => $unit['bom']
            ];
            $overallTotal += $unit['final_price'] * $indep;
        }

        if ($conn > 0) {
            $unit = $buildUnitBom(1, $beamLevels, $tiePerLevel, $rackH, $depth, $beamL, $barType, $beamThick);
            $sName = ($beamL >= 2585 ? "2S" : "1S") . " {$levels}단 연결";
            $modules[] = [
                'type' => '연결',
                'name' => '파렛트랙',
                'spec' => "{$beamL}*{$depth}*{$rackH}",
                'remark' => $sName,
                'qty' => $conn,
                'unit_price' => $unit['final_price'],
                'raw_price' => $unit['raw_price'],
                'total_price' => $unit['final_price'] * $conn,
                'bom' => $unit['bom']
            ];
            $overallTotal += $unit['final_price'] * $conn;
        }

        if ($small > 0) {
            $unit = $buildUnitBom(1, $beamLevels, 2, $rackH, $depth, 1385, $barType, $beamThick);
            $sNameSmall = ($beamL >= 2585 ? "2S" : "1S") . " {$levels}단 작은연결";
            $modules[] = [
                'type' => '작은연결',
                'name' => '파렛트랙',
                'spec' => "1385*{$depth}*{$rackH}",
                'remark' => $sNameSmall,
                'qty' => $small,
                'unit_price' => $unit['final_price'],
                'raw_price' => $unit['raw_price'],
                'total_price' => $unit['final_price'] * $small,
                'bom' => $unit['bom']
            ];
            $overallTotal += $unit['final_price'] * $small;
        }

        // 바이패스(Bypass)
        $bypass = intval($quote['rack_bypass'] ?? 0);
        if ($bypass > 0) {
            $bpLevels = max(1, $levels - 1);
            $bpBeamLevels = max(1, $beamLevels - 1);
            
            // 바이패스: 프레임 1개, 로드빔 쌍은 일반보다 1단 적음
            $unit = $buildUnitBom(1, $bpBeamLevels, $tiePerLevel, $rackH, $depth, $beamL, $barType, $beamThick);
            
            $bpType = $quote['rack_bypass_type'] ?? "1S {$bpLevels}단 연결";
            
            $modules[] = [
                'type' => '바이패스',
                'name' => '파렛트랙',
                'spec' => "{$beamL}*{$depth}*{$rackH}",
                'remark' => $bpType . " (바이패스)",
                'qty' => $bypass,
                'unit_price' => $unit['final_price'],
                'raw_price' => $unit['raw_price'],
                'total_price' => $unit['final_price'] * $bypass,
                'bom' => $unit['bom']
            ];
            $overallTotal += $unit['final_price'] * $bypass;
        }

        // 복렬 홀더(Holder)
        $holders = intval($quote['rack_holders'] ?? 0);
        if ($holders > 0) {
            $hBom = [];
            $hWeight = 0;
            
            $h = \App\Services\SehwaPriceCalculator::calcHolder(['length' => 200, 'thickness' => 2.0, 'qty' => 1]);
            $hBom[] = $h;
            $hWeight += $h['weight'];

            $hBom[] = \App\Services\SehwaPriceCalculator::getFixedPart('FIX-004', 4);
            
            $lossTotal = \App\Services\SehwaPriceCalculator::calcLoss($hWeight);
            if ($lossTotal > 0) {
                $hBom[] = ['name' => 'Loss', 'spec' => '철강 Loss 3%', 'qty' => '-', 'unit_amount' => '-', 'total' => $lossTotal];
            }
            
            $sumRaw = 0;
            foreach ($hBom as $item) { $sumRaw += $item['total']; }
            $hFinal = \App\Services\SehwaPriceCalculator::finalAmount($sumRaw);

            $modules[] = [
                'type' => '홀더',
                'name' => '복렬 홀더',
                'spec' => '200L',
                'remark' => '복식/상하체결',
                'qty' => $holders,
                'unit_price' => $hFinal,
                'raw_price' => $sumRaw,
                'total_price' => $hFinal * $holders,
                'bom' => $hBom
            ];
            $overallTotal += $hFinal * $holders;
        }

        return [
            'modules' => $modules,
            'overallTotal' => $overallTotal
        ];
    }

    public function quoteDocument($vars) {
        $this->requireVendorEmployees();
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            $this->redirect('/login');
            return;
        }
        if (!isset($_SESSION['employee_id'])) {
            $this->redirect('/vendor/profiles');
            return;
        }

        $userId = $_SESSION['user']['user_id'];
        $quoteId = intval($vars['id'] ?? 0);
        $db = Database::getInstance();

        $stmt = $db->prepare("
            SELECT q.*, e.name as employee_name, e.color_code as employee_color, e.phone as employee_phone, e.title as employee_title
            FROM quote_requests q 
            LEFT JOIN vendor_employees e ON q.processed_by = e.id 
            WHERE q.id = :qid AND q.vendor_user_id = :vuid
        ");
        $stmt->execute(['qid' => $quoteId, 'vuid' => $userId]);
        $quote = $stmt->fetch();

        if (!$quote) {
            echo "<script>alert('존재하지 않거나 접근 권한이 없는 견적 요청입니다.'); window.location.href='/vendor/quotes';</script>";
            return;
        }

        $stmt = $db->prepare("SELECT * FROM vendor_settings WHERE user_id = :uid");
        $stmt->execute(['uid' => $userId]);
        $settings = $stmt->fetch() ?: [];

        $result = $this->buildQuoteModules($quote);
        $modules = $result['modules'];

        $this->view('vendor/quote_document', ['quote' => $quote, 'settings' => $settings, 'modules' => $modules]);
    }

    public function sendEmail(array $vars) {
        $id = $vars['id'];
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            return;
        }

        $userId = $_SESSION['user']['user_id'];
        
        $to = $_POST['to'] ?? '';
        $subject = $_POST['subject'] ?? '';
        $body = $_POST['body'] ?? '';
        
        if (empty($to) || empty($subject)) {
            echo json_encode(['success' => false, 'message' => '필수 항목이 누락되었습니다.']);
            return;
        }
        
        $attachments = [];
        
        // Handle PDF Quote
        if (isset($_FILES['quote_pdf']) && $_FILES['quote_pdf']['error'] === UPLOAD_ERR_OK) {
            $tmpPath = $_FILES['quote_pdf']['tmp_name'];
            $name = '견적서_' . date('Ymd_His') . '.pdf';
            $attachments[] = [$tmpPath, $name];
        } else {
            echo json_encode(['success' => false, 'message' => 'PDF 변환 파일이 수신되지 않았습니다.']);
            return;
        }
        
        // Handle Extra Files
        if (isset($_FILES['extra_files'])) {
            $files = $_FILES['extra_files'];
            for ($i = 0; $i < count($files['name']); $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $attachments[] = [$files['tmp_name'][$i], $files['name'][$i]];
                }
            }
        }
        
        // Send Email using existing Mailer
        require_once __DIR__ . '/../../lib/mailer.lib.php';
        $result = \Mailer::send($to, $subject, $body, $attachments, false);
        
        if ($result['success']) {
            $db = \App\Core\Database::getInstance();
            $employeeId = $_SESSION['employee_id'] ?? null;
            if ($employeeId) {
                $stmt = $db->prepare("UPDATE quote_requests SET processed_by = ?, processed_at = NOW() WHERE id = ?");
                $stmt->execute([$employeeId, $id]);
            }
            echo json_encode(['success' => true, 'message' => '메일이 성공적으로 발송되었습니다.']);
        } else {
            echo json_encode(['success' => false, 'message' => '발송 실패: ' . $result['message']]);
        }
    }
}
